/*
 * CoDiPack, a Code Differentiation Package
 *
 * Copyright (C) 2015-2024 Chair for Scientific Computing (SciComp), University of Kaiserslautern-Landau
 * Homepage: http://www.scicomp.uni-kl.de
 * Contact:  Prof. Nicolas R. Gauger (codi@scicomp.uni-kl.de)
 *
 * Lead developers: Max Sagebaum, Johannes Blühdorn (SciComp, University of Kaiserslautern-Landau)
 *
 * This file is part of CoDiPack (http://www.scicomp.uni-kl.de/software/codi).
 *
 * CoDiPack is free software: you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * CoDiPack is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 * You should have received a copy of the GNU
 * General Public License along with CoDiPack.
 * If not, see <http://www.gnu.org/licenses/>.
 *
 * For other licensing options please contact us.
 *
 * Authors:
 *  - SciComp, University of Kaiserslautern-Landau:
 *    - Max Sagebaum
 *    - Johannes Blühdorn
 *    - Former members:
 *      - Tim Albring
 */
#pragma once

#include "reverse1stOrderBase.hpp"

struct CoDiReverse1stOrderVectorHelper : public CoDiReverse1stOrderBase {
  public:

    using Number = CODI_TYPE;

    using Base = CoDiReverse1stOrderBase;

    using Gradient = Number::Gradient;

    codi::CustomAdjointVectorHelper<Number, Gradient> helper;

    CoDiReverse1stOrderVectorHelper() : Base(), helper() {}

    Gradient& accessGradient(Number& value) {
      return helper.gradient(value.getIdentifier());
    }

    void cleanup() {
      helper.clearAdjoints();
    }

    void evaluate() {
      helper.evaluate();
    }

    void prepare() {}
};
