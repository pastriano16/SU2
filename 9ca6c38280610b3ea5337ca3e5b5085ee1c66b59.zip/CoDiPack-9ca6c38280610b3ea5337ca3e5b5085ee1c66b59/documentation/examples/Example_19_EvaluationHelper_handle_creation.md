Example 19 - EvaluationHelper handle creation {#Example_19_EvaluationHelper_handle_creation}
=======

**Goal:** Possible definitions of function objects for the codi::EvaluationHelper

**Prerequisite:** None

**Function:**
\snippet examples/Example_19_EvaluationHelper_handle_creation.cpp Function

**Full code:**
\snippet examples/Example_19_EvaluationHelper_handle_creation.cpp Example 19 - Evaluation helper handle creation

Demonstration of handle creations for the EvaluationHelper class. For a detailed documentation please see the
[EvaluationHelper](@ref codi::EvaluationHelper) documentation.
