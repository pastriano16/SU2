Example 16 - TapeHelper {#Example_16_TapeHelper}
=======

**Goal:** Demonstration of a simplified tape interface.

**Prerequisite:** None

**Function:**
\snippet examples/Example_16_TapeHelper.cpp Function

**Full code:**
\snippet examples/Example_16_TapeHelper.cpp Example 16 - Tape helper

Demonstration of the TapeHelper class for a simplified handling of CoDiPack tapes. For a detailed documentation please
see the [TapeHelper](@ref codi::TapeHelperBase) documentation.
