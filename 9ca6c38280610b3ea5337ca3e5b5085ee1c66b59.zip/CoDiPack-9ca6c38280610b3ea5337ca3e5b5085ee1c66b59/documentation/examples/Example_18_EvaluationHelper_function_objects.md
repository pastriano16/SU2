Example 18 - EvaluationHelper function object declaration {#Example_18_EvaluationHelper_function_objects}
=======

**Goal:** Possible definitions of function objects for the codi::EvaluationHelper

**Prerequisite:** None

**Function:**
\snippet examples/Example_18_EvaluationHelper_function_objects.cpp Function

**Full code:**
\snippet examples/Example_18_EvaluationHelper_function_objects.cpp Example 18 - Evaluation helper function objects

Demonstration of different function objcects for the EvaluationHelper class. For a detailed documentation please see the
[EvaluationHelper](@ref codi::EvaluationHelper) documentation.
