Example 4 - Higher order derivatives compile time access {#Example_04_Higher_order_types_helper_access_compile_time}
============

**Goal:** Demonstation of the compile time access interface of the [DerivativeAccess](@ref codi::DerivativeAccess) helper.

**Prerequisite:** \ref Tutorial_06_Higher_order_types_helper_acces

**Function:** \ref func_simple1to1_higher
\snippet examples/Example_04_Higher_order_types_helper_access_compile_time.cpp Function

**Full code:**
\snippet examples/Example_04_Higher_order_types_helper_access_compile_time.cpp Example 4: Higher order derivatives compile time access
