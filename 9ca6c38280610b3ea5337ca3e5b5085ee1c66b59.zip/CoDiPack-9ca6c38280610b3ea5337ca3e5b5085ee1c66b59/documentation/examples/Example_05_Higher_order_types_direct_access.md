Example 5 - Higher order derivatives direct access {#Example_05_Higher_order_types_direct_access}
============

**Goal:** Demonstation how to set derivatives of higher order types directly.

**Prerequisite:** \ref Tutorial_06_Higher_order_types_helper_acces

**Function:** \ref func_simple1to1_higher
\snippet examples/Example_05_Higher_order_types_direct_access.cpp Function

**Full code:**
\snippet examples/Example_05_Higher_order_types_direct_access.cpp Example 5: Higher order derivatives direct access
