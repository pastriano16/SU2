Example 24 - Enzyme external function helper {#Example_24_Enzyme_external_function_helper}
=======

**Goal:** Add external functions to the tape via Enzyme.

**Prerequisite:** \ref Example_10_External_function_helper

**Function:**
\snippet examples/Example_24_Enzyme_external_function_helper.cpp Function implementations

**Full code:**
\snippet examples/Example_24_Enzyme_external_function_helper.cpp Example 24 - Enzyme external function helper
