Papers {#Papers}
=======

 - \anchor SBG2021Index __SBG2021Index:__ M. Sagebaum, J. Blühdorn, N.R. Gauger, Index handling and assign optimization for Algorithmic Differentiation reuse index managers. arXiv cs.MS 2006.12992, 2021.
 - \anchor SAG2019High __SAG2019High:__   M. Sagebaum, T. Albring, N.R. Gauger, High-Performance Derivative Computations using CoDiPack. ACM Transactions on Mathematical Software (TOMS), 45 (4), 2019.
 - \anchor SAG2018Expression __SAG2018Expression:__ M. Sagebaum; T. Albring; N. R. Gauger, Expression templates for primal value taping in the reverse mode of algorithmic differentiation. Optimization Methods and Software, 33 (4-6), pp. 1207-1231, 2018.
